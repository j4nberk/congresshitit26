<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class HRCheck_Ajax {

    public function register() {
        add_action( 'wp_ajax_hrcheck_query', array( $this, 'handle_query' ) );
        add_action( 'wp_ajax_nopriv_hrcheck_query', array( $this, 'handle_query' ) );
    }

    public function handle_query() {
        // Nonce
        if ( ! check_ajax_referer( 'hrcheck_query', 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => 'Güvenlik doğrulaması başarısız.' ) );
        }

        $settings = get_option( 'hrcheck_settings', array() );

        // ── reCAPTCHA DOĞRULAMA ──
        $secret_key = $settings['recaptcha_secret_key'] ?? '';
        if ( $secret_key ) {
            $recaptcha_response = sanitize_text_field( $_POST['recaptcha'] ?? '' );
            if ( empty( $recaptcha_response ) ) {
                wp_send_json_error( array( 'message' => 'Lütfen "Ben robot değilim" doğrulamasını tamamlayın.' ) );
            }

            $verify = wp_remote_post( 'https://www.google.com/recaptcha/api/siteverify', array(
                'body' => array(
                    'secret'   => $secret_key,
                    'response' => $recaptcha_response,
                    'remoteip' => $_SERVER['REMOTE_ADDR'] ?? '',
                ),
            ));

            if ( is_wp_error( $verify ) ) {
                wp_send_json_error( array( 'message' => 'reCAPTCHA doğrulaması sırasında hata oluştu.' ) );
            }

            $verify_body = json_decode( wp_remote_retrieve_body( $verify ), true );
            if ( empty( $verify_body['success'] ) ) {
                wp_send_json_error( array( 'message' => 'reCAPTCHA doğrulaması başarısız. Lütfen tekrar deneyin.' ) );
            }
        }

        // ── TELEFON DOĞRULAMA ──
        $phone_raw = preg_replace( '/\D/', '', sanitize_text_field( $_POST['phone'] ?? '' ) );

        if ( ! $phone_raw || ! preg_match( '/^05[0-9]{9}$/', $phone_raw ) ) {
            wp_send_json_error( array( 'message' => 'Geçerli bir telefon numarası girin (05XX XXX XX XX).' ) );
        }

        // ── AYARLARI KONTROL ET ──
        $apps_url    = $settings['apps_script_url'] ?? '';
        $search_col  = $settings['search_column'] ?? 'A';
        $result_col1 = $settings['result_col_1'] ?? 'B';
        $result_col2 = $settings['result_col_2'] ?? 'C';

        if ( empty( $apps_url ) ) {
            wp_send_json_error( array( 'message' => 'Sistem yapılandırması eksik. Lütfen yönetici ile iletişime geçin.' ) );
        }

        // ── GOOGLE SHEETS SORGUSU ──
        $query_url = add_query_arg( array(
            'phone'      => $phone_raw,
            'searchCol'  => $search_col,
            'resultCol1' => $result_col1,
            'resultCol2' => $result_col2,
        ), $apps_url );

        $response = wp_remote_get( $query_url, array(
            'timeout'   => 15,
        ) );

        if ( is_wp_error( $response ) ) {
            error_log( 'HRCheck Sheets hatası: ' . $response->get_error_message() );
            wp_send_json_error( array( 'message' => 'Sorgulama sırasında bir hata oluştu. Lütfen tekrar deneyin.' ) );
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );

        // Apps Script redirect takibi (302 → HTML sayfası dönebilir)
        $data = json_decode( $body, true );

        if ( ! is_array( $data ) ) {
            error_log( 'HRCheck: Sheets yanıtı JSON değil. HTTP ' . $code . ' Body: ' . substr( $body, 0, 300 ) );
            wp_send_json_error( array( 'message' => 'Sorgulama sırasında bir hata oluştu. Lütfen tekrar deneyin.' ) );
        }

        if ( ! empty( $data['error'] ) ) {
            wp_send_json_error( array( 'message' => $data['error'] ) );
        }

        if ( empty( $data['found'] ) ) {
            $not_found = $settings['not_found_msg'] ?? 'Bu telefon numarasına ait kayıt bulunamadı.';
            wp_send_json_error( array( 'message' => $not_found, 'type' => 'not_found' ) );
        }

        // ── BAŞARILI SONUÇ ──
        wp_send_json_success( array(
            'result1' => sanitize_text_field( $data['result1'] ?? '' ),
            'result2' => sanitize_text_field( $data['result2'] ?? '' ),
        ));
    }
}